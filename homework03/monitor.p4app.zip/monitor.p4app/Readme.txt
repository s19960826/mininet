In this assignment, we create a counter called 'ctr' in monitor.p4.

The amount of traffic generate by h1,h2 and h3 will be stored in ctr[0], ctr[1] and ctr[2], respectively.






